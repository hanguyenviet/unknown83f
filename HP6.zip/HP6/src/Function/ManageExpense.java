/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Function;

import Model.Expense;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import validator.getInput;
import view.display;

/**
 *
 * @author ADMIN
 */
public class ManageExpense {

    public static void addExpense(ArrayList<Expense> listEx) {
//        listEx.add(new Expense(1, "12-2-2022", 1200.2222222222222, "fee"));
//        listEx.add(new Expense(2, "12-3-2022", 1500, "food"));
//        listEx.add(new Expense(3, "12-4-2022", 1300, "rent house"));
        int id;
        if (listEx.isEmpty()) {
            id = 1;
        } else {
            id = listEx.get(listEx.size() - 1).getId() + 1;
        }
        String date = getInput.getDate("Enter date: ","dd-MM-yyyy",
                "Date is invalid!", "ne",
                "Date can not in the future!");
        double number = getInput.getLimitDouble("Enter Amount: ", Double.MIN_VALUE,
                Double.MAX_VALUE, "Enter only number!", "");
        String content = getInput.getStringFormat("Enter Content: ", "^(\\s*[a-zA-Z]+\\s*){1,}$",
                "Your input is not valid!");
        listEx.add(new Expense(id, date, number, content));
    }

    public static void displayExpense(ArrayList<Expense> listEx) {
        if (listEx.isEmpty()) {
            System.out.println("List is empty! Add first!");
        } else {
            Collections.sort(listEx, new Comparator<Expense>() {
                @Override
                public int compare(Expense o1, Expense o2) {
                    boolean check = o1.getNumber() >= o2.getNumber();
                    int comp = 0 ;
                    if (check) {
                        comp = 1;
                    } else {
                        comp = -1;
                    }
                    return comp;
                }
            });
            System.out.printf("%-5s%-20s%-20s%-15s\n", "ID", "Date", "Amount of money", "Content");
            int sum = 0;
            for (int i = 0; i < listEx.size(); i++) {
                display.displayEx(listEx.get(i));
                sum += listEx.get(i).getNumber();
            }
            System.out.println("Total: " + sum);
        }
    }

    public static void deleteExpense(ArrayList<Expense> listEx) {
        if (listEx.isEmpty()) {
            System.out.println("List is empty! Add first!");
        } else {
            int idInput = getInput.getLimitInt("Enter ID to delete",
                    "Enter number only!", "", Integer.MIN_VALUE, Integer.MAX_VALUE);
            int pos=-1;
            for (int i = 0; i < listEx.size(); i++) {
                if (listEx.get(i).getId() == idInput) {
                    pos = i;
                    break;
                } else {
                    pos = -1;
                }
            }
            if (pos < 0) {
                System.out.println("Delete an expense fail!");
            } else {
                listEx.remove(pos);
//                for (int i = 0; i < listEx.size(); i++) {
//                    listEx.get(i).setId(i+1);
//                }
                System.out.println("Delete an expense successful!");
            }
        }
    }

}
