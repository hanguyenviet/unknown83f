/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Function.ManageExpense;
import Model.Expense;
import java.util.ArrayList;
import view.display;

/**
 *
 * @author ADMIN
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Expense> listEx= new ArrayList<>();
        while (true) {
            //display menu
            display.displayMenu();
            //user enter choice
            int userChoice = validator.getInput.getLimitInt("Enter choice: ", "Enter only number!",
                    "Please enter inrange 1-4!", 1, 4);
            switch (userChoice) {
                //Option 1: enter information of country
                case 1:
                    ManageExpense.addExpense(listEx);
                    break;
                //Option 2:display information of country
                case 2:
                    ManageExpense.displayExpense(listEx);
                    break;
                //Option 3: Search the country according to the entered country's name.
                case 3:
                    ManageExpense.deleteExpense(listEx);
                    break;
                //Option 4: Display the information increasing with the country name.
                case 4:
                    System.exit(0);
            }
        }
    }
    
}
