/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import Model.Expense;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class display {

    public static void displayMenu() {
        System.out.println("=======Handy Expense program======\n"
                + "1. Add an expense\n"
                + "2. Display all expenses\n"
                + "3. Delete an expense\n"
                + "4. Quit");
    }

    public static void displayEx(Expense ex) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            SimpleDateFormat sdfPrint = new SimpleDateFormat("d-MMM-yyyy");
            Date dateFormat = sdf.parse(ex.getDate());
            String date = sdfPrint.format(dateFormat);
            System.out.printf("%-5d%-20s%-20.3f%-15s\n",
                    ex.getId(),
                    date,
                    ex.getNumber(),
                    ex.getContent());
        } catch (ParseException ex1) {
            Logger.getLogger(display.class.getName()).log(Level.SEVERE, null, ex1);
        }
    }
}
