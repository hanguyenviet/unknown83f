/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author ADMIN
 */
public class getInput {

    public static int getLimitInt(String messageInfor, String messageError,
            String messageOutRange, int min, int max) {
        System.out.println(messageInfor);
        //user enter input
        Scanner input = new Scanner(System.in);
        int number = 0;
        while (true) {
            try {
                String inputNumber = input.nextLine();
                //check input is number or not
                number = Integer.parseInt(inputNumber);
                //check number in range or not
                if (min <= number && number <= max) {
                    break;
                } else {
                    System.out.println(messageOutRange);
                }
                //return value of input if correct
            } catch (Exception e) {
                System.out.println(messageError);
            }
        }
        return number;
    }

    public static String getStringFormat(String messageInfor, String format,
            String messageError) {
        System.out.println(messageInfor);
        Scanner input = new Scanner(System.in);
        String userInput;
        while (true) {
            //enter input
            userInput = input.nextLine();
            userInput = userInput.trim();
            userInput = userInput.replaceAll("\\s+", " ");
            //create regex
            Pattern form = Pattern.compile(format);
            //check correct format
            Matcher check = form.matcher(userInput);
            if (check.find()) {
                return userInput;
            } else {
                System.out.println(messageError);
            }

        }
    }

    public static double getLimitDouble(String messageInfor,
            double min, double max, String messageError, String messageOutRange) {
        System.out.println(messageInfor);
        //user enter input
        Scanner input = new Scanner(System.in);
        double number = 0;
        while (true) {
            try {
                String inputNumber = input.nextLine();
                //check input is number or not
                number = Double.parseDouble(inputNumber);
                //check number in range or not
                if (min <= number && number <= max) {
                    break;
                } else {
                    System.out.println(messageOutRange);
                }
                //return value of input if correct
            } catch (Exception e) {
                System.out.println(messageError);
            }
        }
        return number;
    }

    public static String getDate(String messageInfor, String format,
            String messWrongForm, String compare, String messageError) {
        String userInput;
        Date now = new Date();
        //user enter input
        Scanner input = new Scanner(System.in);
        while (true) {
            try {
                System.out.println(messageInfor);
                userInput = input.nextLine();
                SimpleDateFormat sdf = new SimpleDateFormat(format);
                sdf.setLenient(false);
                Date date = sdf.parse(userInput); 
                if (compare.equalsIgnoreCase("gr")) {
                    if (date.after(now)) {
                        break;
                    }else{
                        System.out.println(messageError);
                    }
                } else if (compare.equalsIgnoreCase("eq")) {
                    if (date.equals(now)) {
                        break;
                    }else{
                        System.out.println(messageError);
                    }
                } else if (compare.equalsIgnoreCase("ne")) {
                    if (date.before(now)) {
                        break;
                    }else{
                        System.out.println(messageError);
                    }
                }else{
                    break;
                }
            } catch (ParseException ex) {
                System.out.println(messWrongForm);
            }
        }
        return userInput;

    }

}
